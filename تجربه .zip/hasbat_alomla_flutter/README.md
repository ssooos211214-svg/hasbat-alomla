
# حاسبة العملة

تطبيق Flutter بسيط لتحويل الريال السعودي إلى الدولار الأمريكي.

## التشغيل

```bash
flutter pub get
flutter run
```

## استخراج IPA

على جهاز Mac مع Xcode:

```bash
flutter build ipa
```
